<?php
function printr($value)
{
   echo '<pre>';
   print_r($value);  
   echo '</pre>';
}

?>