<?php
 // session_start();
  

class WebsiteSettings
{
	
	var $mSettings = false;
		// echo $u_id;
  
function getId(){

  if(isset($_GET['id'])){
    
    return $_GET['id'];
  }
  	
}


	function __construct()
	{
		 // session_start();;
		global $db;
		// $crntVar =$smarty->getTemplateVars();
		// print_r($smarty);
		// global $id;
		$u_id=$this->getId();
		if (isset($u_id)) {
			$sql = 'SELECT * FROM '.DB_PREFIX.' settings WHERE user_id='.$u_id.' ORDER BY id ASC';
		}else{
			$sql = 'SELECT * FROM '.DB_PREFIX.' settings ORDER BY id ASC';
		}
		
		

		$result = $db->query($sql);
		
		$settings = array();
		
		while ($row = $result->fetch_assoc())
		{
			// Setting temporary variable names for the 'value' and 'fieldtype' fields
			$value = $row['value']; 
			$data_type = $row['data_type'];
			$input_type = $row['input_type'];
			$input_options = $row['input_options'];
			$validation = explode('|', $row['validation']); 
				
			// Apply certain actions on special fields 
			if ($input_type == 'checkbox' || $input_type == 'select' || $input_type == 'radiobutton')
				$input_options = explode('|', $input_options);
			elseif ($input_type == 'available_themes')
			{
				$input_type = 'select';	$themes = array();
				$dir = APP_PATH.'_templates/';
				if ($dh = opendir($dir)) {
				    while (($file = readdir($dh)) !== false) { if (filetype($dir . $file) != 'file' && $file != '.' && $file != '..' && $file != '.svn' && $file != '_cache') $themes[] = $file; }
					closedir($dh);
				}
				$input_options = $themes;
			}
			if ($data_type == 'boolean' && $value != 1) $value = false;
				
			// Add the row to the setting array
			$settings[$row['name']] = array(
				'name' => $row['name'], 
				'title' => $row['title'], 
				'description' => $row['description'],
				'data_type' => $data_type,
				'input_type' => $input_type,
				'input_options' => $input_options,
				'validation' => $validation,
				'value' => stripslashes($value), 
				'category_id' => $row['category_id'] 
				);
		}
		
		$this->mSettings = $settings;

	}
	
	public function GetSettingsCategories()
	{
	    global $db;
	    $sql = 'SELECT id, name, var_name, description  
				FROM '.DB_PREFIX.'settings_categories 
				ORDER BY id ASC';


	    	$result = $db->query($sql);
	    $settings_category = array();
		
		while ($row = $result->fetch_assoc())
		{
			$settings_category[] = array('name' => $row['name'], 'var_name' => $row['var_name'], 'description' => $row['description']);
		}
		return $settings_category;

	}

	public function GetSettingsCategoryNameById($id)
	{
		global $db;
	    $sql = 'SELECT name 
				FROM '.DB_PREFIX.'settings_categories 
				WHERE id = ' . $id;
	    $result = $db->query($sql);
	    $row = $result->fetch_assoc();
		return $row['name'];
	}
	
	public function GetSettingsCategoryIdByVarname($var_name)
	{
		global $db;
	    $sql = 'SELECT id 
				FROM '.DB_PREFIX.'settings_categories 
				WHERE var_name = "' . $var_name . '"';
				// echo $sql;
	    $result = $db->query($sql);
	    $row = $result->fetch_assoc();
		return $row['id'];
	}

	public function GetSetting($name, $advanced = false)
	{
		$settings = $this->mSettings;
		if (!empty($settings[$name]))
		{
			if ($advanced == true) return $settings[$name];
			else return $settings[$name]['value'];
		}
		else
			return false;
	}
	
	public function GetSettings($setting_names = false, $advanced = false)
	{
		$settings = $this->mSettings;
		$settings_array = array();
		
		if (!empty($setting_names))
		{
			$i = 0; while($i < count($setting_names))
			{
				if (!empty($settings[$setting_names[$i]]) && $advanced == true) 
					$settings_array[$setting_names[$i]] = $settings[$setting_names[$i]];
				elseif (!empty($settings[$setting_names[$i]]))
					$settings_array[$setting_names[$i]] = $settings[$setting_names[$i]]['value'];
				$i++;
			}
			return $settings_array;
		}
		elseif ($advanced == false)
		{
			foreach ($settings as $setting)
			{
				$settings_array[$setting['name']] = $setting['value'];
			}
			return $settings_array;
		}
		else return $settings;
	}
	
	public function GetSettingsByCategory($category_id, $advanced = false)
	{
		global $db;
		$sql = 'SELECT name
				FROM '.DB_PREFIX.'settings
				WHERE category_id = ' . $category_id . ' AND user_id='.$_SESSION['AdminId'].' ORDER BY ordering ASC';
				echo $sql;
		$result = $db->query($sql);
		
		$settings_list = array();
		
		while ($row = $result->fetch_assoc()) {	$settings_list[] = $row['name']; }

		$settings = $this->GetSettings($settings_list, $advanced);

		return $settings;
	}

	public function UpdateSettings($settings_array,$settings_category_id)
	{
		global $db;
     // print_r($settings_array);
     $checkQuery = 'SELECT * FROM '.DB_PREFIX.'settings WHERE user_id='.$_SESSION['AdminId'].' AND category_id='.$settings_category_id;
      // echo $checkQuery;
       $result = $db->QueryRow($checkQuery);
  // echo $result;
    if ($result == 0) {
    	$settings = $this->mSettings; $i = 0;
		
		while($i < count($settings_array))
		{
			$value = $settings_array[$i]['value'];
			$name = $settings_array[$i]['name'];
			
			if ($value != $settings[$name]['value'])
			{
				$sql = 'UPDATE '.DB_PREFIX.'settings SET value = "' . $value . '" WHERE name = "' . $name . '"';
				$db->query($sql);
			}
			$i++;
		}

    }else{

    	"Inserted Manzar";
    }
		
		
	}
}
?>