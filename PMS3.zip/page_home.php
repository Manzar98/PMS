<?php


	 // $smarty->assign('seo_title', htmlspecialchars($settings['html_title']) . ' - ' .SITE_NAME);
	 // $smarty->assign('seo_desc', htmlspecialchars($settings['meta_description']));
	 // $smarty->assign('seo_keys', htmlspecialchars($settings['meta_keywords']));
?>