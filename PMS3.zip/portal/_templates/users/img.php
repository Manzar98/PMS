<?php
// print_r($_POST) ;
  $data = $_POST['image'];


list($type, $data) = explode(';', $data);
list(, $data)      = explode(',', $data);


$data = base64_decode($data);
$imageName = time().'.png';
 file_put_contents('../img/uploads/'.$imageName, $data);

 $storedimg='../img/uploads/'.$imageName;
echo $storedimg;
 // $res_Array=array(
 //    "status"=>"Success",
 //     "imgpath"=> $storedimg);

 //      json_encode($res_Array);
   
?>