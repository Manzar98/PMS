<?php
 
  $users = new User;
  $user_list="";
 
if($_POST)
{
	$data['name'] = $_POST['name'];
	$data['password'] = $_POST['password'];
	$data['email'] = $_POST['email'];
	$data['expire'] = $_POST['expire'];
	$data['F_name'] = $_POST['F_name'];
	$data['L_name'] = $_POST['L_name'];
	$data['city'] = $_POST['city'];
	$data['c_address'] = $_POST['c_address'];
	$data['quali'] = $_POST['quali'];
	$data['exprience'] = $_POST['exprience'];
	$data['work_day'] = $_POST['work_day'];
	$data['work_hr'] = $_POST['work_hr'];
	$data['mobile'] = $_POST['mobile'];
	$data['phone'] = $_POST['phone'];
	if($data['name']=='')
	{
		$errors['name'] = 'Please Enter Name';
	}

	if($data['password']=='')
	{
		$errors['password'] = 'Please Enter Password';
	}

	if($data['email']=='')
	{
		$errors['email'] = 'Please Enter Email address';
	}

	if($data['expire']=='')
	{
		$errors['expire'] = 'Please Enter Expiration Date';
	}
	if (isset($id)) {
		
		$data['id']=$id;
	}
	$data = escape($data);
	 
	if(empty($errors))
	{     
		// echo "enter here";

		if($users->updateUser($data))
		{
			// print_r($getId);
			 redirect_to(BASE_URL.'users/');
		}
	}	
}
elseif($id>0)
  {

	  $user_details = $users->GetUserInfo($id);
	 
  }
   if (isset($user_details)) {
   	$smarty->assign('data',$user_details);
   }

  
  $template = "users/edit_user.tpl";
?>