<?php

$users = new User;

// echo $id;
// print_r($page);
if (isset($_GET['img']) && $_GET['img']=='y') {
	
$data = $_POST['image'];

list($type, $data) = explode(';', $data);
list(, $data)      = explode(',', $data);
$data = base64_decode($data);
$imageName = time().'.png';
 file_put_contents('{$BASE_URL_ADMIN}_templates/img/uploads/'.$imageName, $data);
 $storedimg='{$BASE_URL_ADMIN}_templates/img/uploads/'.$imageName;
echo $storedimg;


}
else if($_POST)
{


	$data = array();
	$data['name'] = $_POST['name'];
	$data['password'] = $_POST['password'];
	$data['email'] = $_POST['email'];
	$data['expire'] = $_POST['expire'];
	$data['F_name'] = $_POST['F_name'];
	$data['L_name'] = $_POST['L_name'];
	$data['city'] = $_POST['city'];
	$data['c_address'] = $_POST['c_address'];
	$data['quali'] = $_POST['quali'];
	$data['exprience'] = $_POST['exprience'];
	$data['mobile'] = $_POST['mobile'];
	$data['phone'] = $_POST['phone'];
	$data['profile_img'] = $_POST['profile_img'];
	if($data['name']=='')
	{
		$errors['name'] = 'Please Enter Name';
	}

	if($data['password']=='')
	{
		$errors['password'] = 'Please Enter Password';
	}

	if($data['email']=='')
	{
		$errors['email'] = 'Please Enter Email address';
	}

	if($data['expire']=='')
	{
		$errors['expire'] = 'Please Enter Expiration Date';
	}
	
	if(empty($errors))
	{
		if($users->AddUser($data))
		{

			// redirect_to(BASE_URL);
			echo "Inserted Manzaer";
		}
		

	}
	else {
		$smarty->assign('errors',$errors);
		$smarty->assign('data',$data);
	}
	 
}

if (!isset($_GET['img'])) {
	$template = 'users/add_user.tpl';
}



?>