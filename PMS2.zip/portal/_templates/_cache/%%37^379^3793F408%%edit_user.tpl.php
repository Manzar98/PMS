<?php /* Smarty version 2.6.31, created on 2018-08-27 19:48:44
         compiled from users/edit_user.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'print_r', 'users/edit_user.tpl', 16, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		<div id="content">
			
			

				<h2>Add User</h2>
				
				<?php if (( isset ( $this->_tpl_vars['errors'] ) && $this->_tpl_vars['errors'] )): ?>
					<div class="fail">
						<?php $_from = $this->_tpl_vars['errors']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['error']):
?>
							<?php echo $this->_tpl_vars['error']; ?>

						<?php endforeach; endif; unset($_from); ?>
					</div>
					<?php endif; ?>
			 <!-- <?php echo $_SERVER['REQUEST_URI']; ?>
  -->
			 <!-- <?php echo ((is_array($_tmp=$this->_tpl_vars['data'])) ? $this->_run_mod_handler('print_r', true, $_tmp) : print_r($_tmp)); ?>
 -->
			<form id="add_user" class="box style" action="<?php echo $_SERVER['REQUEST_URI']; ?>
" method="post">
				<fieldset>
					<legend>Edit User</legend>
					<div class="row">
						<div class="col-sm-4 common-bottom">
							<label for="name">User Name</label>
							<input type="text" name="name" id="name" class="form-control" <?php if (( isset ( $this->_tpl_vars['data'] ) && $this->_tpl_vars['data']['username'] )): ?>value="<?php echo $this->_tpl_vars['data']['username']; ?>
"<?php endif; ?>/>
						</div>
						<div class="col-sm-4 common-bottom">
							<label for="email">Email address</label>
							<input type="email" name="email" id="email" class="form-control" <?php if (( isset ( $this->_tpl_vars['data'] ) && $this->_tpl_vars['data']['email'] )): ?>value="<?php echo $this->_tpl_vars['data']['email']; ?>
"<?php endif; ?>/>
						</div>
						<div class="col-sm-4 common-bottom">
							<label for="expire">Expiration</label>
							<input type="text" name="expire" id="expire" class="form-control" <?php if (( isset ( $this->_tpl_vars['data'] ) && $this->_tpl_vars['data']['expire'] )): ?>value="<?php echo $this->_tpl_vars['data']['expire']; ?>
"<?php endif; ?>/>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-4 common-bottom">
							<label for="password">Password</label>
							<input type="password" name="password" id="password"class="form-control" <?php if (( isset ( $this->_tpl_vars['data'] ) && $this->_tpl_vars['data']['password'] )): ?>value="<?php echo $this->_tpl_vars['data']['password']; ?>
"<?php endif; ?>/>
						</div>
						<div class="col-sm-4 common-bottom" style="padding-top: 25px;">

							<input type="submit" name="submit" id="submit" class="btn btn-primary"/>
						</div>
					</div>
				</fieldset>			

			</form>
			
		</div><!-- #content -->

	<?php echo '
		<script type="text/javascript">
			$(document).ready(function()
			{
				$(\'#name\').focus();
				
				$("#add_user").validate({
					rules: {
						name: { required: true },
						password: { required: true }
					}
				});
			
		var today = new Date();
		$( "#expire" ).datepicker({
			dateFormat : "yy-mm-dd",
			changeMonth: true,
			minDate: today,
		});
	});
		</script>
		'; ?>


<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>