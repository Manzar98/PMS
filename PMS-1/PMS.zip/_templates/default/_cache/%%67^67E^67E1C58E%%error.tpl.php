<?php /* Smarty version 2.6.26, created on 2012-03-20 15:35:17
         compiled from error.tpl */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

		<div id="main-body">
			<div id="body-left">
			<div id="no-ads">
				<p><?php echo $this->_tpl_vars['translations']['notfound']['message']; ?>
</p>
				<p>
					<a href="<?php echo $this->_tpl_vars['BASE_URL']; ?>
"><?php echo $this->_tpl_vars['translations']['notfound']['back']; ?>
</a>
				</p>
			</div>
</div>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>