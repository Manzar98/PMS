<?php /* Smarty version 2.6.26, created on 2012-03-20 15:34:35
         compiled from footer.tpl */ ?>

<div class="fix"></div>

	<div id="footer">

		<p>Copyright &copy; 2003-2011 <?php echo $this->_tpl_vars['SITE_NAME']; ?>
. All Rights Reserved. </p>

	</div>

</div>


</div>

</body>
</html>