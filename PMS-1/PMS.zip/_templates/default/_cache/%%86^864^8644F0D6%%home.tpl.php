<?php /* Smarty version 2.6.26, created on 2012-09-02 14:54:56
         compiled from home.tpl */ ?>
