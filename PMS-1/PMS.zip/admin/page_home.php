<?php
	
	try { 
   			$template = 'index.tpl'; 
		} catch (Exception $e) { 
		   echo "Error: " . $e->getMessage(); 
		}
?>